extends Node3D

# ============================================================
# PROJECTILE
# Projétil visível com detecção física por raycast.
# ============================================================

@export var speed: float = 65.0
@export var damage: float = 25.0
@export var lifetime: float = 2.5

var direction: Vector3 = Vector3.FORWARD
var shooter: Node3D = null

var elapsed_time: float = 0.0
var initialized: bool = false


func _ready() -> void:
    set_physics_process(true)


func setup(
    shot_direction: Vector3,
    source: Node3D
) -> void:
    direction = shot_direction.normalized()
    shooter = source
    initialized = true

    if direction.length_squared() > 0.001:
        look_at(global_position + direction, Vector3.UP)


func _physics_process(delta: float) -> void:
    if not initialized:
        return

    elapsed_time += delta

    if elapsed_time >= lifetime:
        queue_free()
        return

    var movement: Vector3 = direction * speed * delta

    var next_position: Vector3 = global_position + movement

    var query := PhysicsRayQueryParameters3D.create(
        global_position,
        next_position
    )

    query.collision_mask = 1
    query.collide_with_bodies = true
    query.collide_with_areas = false

    if is_instance_valid(shooter):
        query.exclude = [shooter.get_rid()]

    var space_state: PhysicsDirectSpaceState3D = (
        get_world_3d().direct_space_state
    )

    var result: Dictionary = space_state.intersect_ray(query)

    if not result.is_empty():
        _handle_collision(result)
        return

    global_position = next_position


func _handle_collision(result: Dictionary) -> void:
    var collider: Object = result.get("collider")

    if collider != null and collider.has_method("take_damage"):
        collider.call("take_damage", damage)

        print("Projétil acertou alvo. Dano: ", damage)

    queue_free()