extends Node3D

const PROJECTILE_SCENE: PackedScene = preload("res://scenes/combat/Projectile.tscn")

@export var fire_rate: float = 0.25
@export var projectile_damage: float = 25.0
@export var projectile_speed: float = 65.0
@export var max_shoot_distance: float = 1000.0

@export var muzzle_path: NodePath = NodePath("MuzzlePoint")

var muzzle_point: Node3D
var fire_cooldown: float = 0.0
var shot_audio: AudioStreamPlayer3D


func _ready() -> void:
	muzzle_point = get_node_or_null(muzzle_path) as Node3D
	_create_shot_audio()


func _process(delta: float) -> void:
	fire_cooldown = maxf(0.0, fire_cooldown - delta)


func fire(camera: Camera3D, shooter: Node3D) -> bool:
	if camera == null or shooter == null:
		return false

	if fire_cooldown > 0.0:
		return false

	var inventory: Node = shooter.get_node_or_null("PlayerInventory")
	if inventory == null:
		return false

	if not bool(inventory.call("consume_ammo", 1)):
		return false

	var viewport := camera.get_viewport()
	var screen_center: Vector2 = viewport.get_visible_rect().size * 0.5
	var ray_origin: Vector3 = camera.project_ray_origin(screen_center)
	var ray_direction: Vector3 = camera.project_ray_normal(screen_center)
	var ray_end: Vector3 = ray_origin + ray_direction * max_shoot_distance

	var query := PhysicsRayQueryParameters3D.create(ray_origin, ray_end)
	query.collision_mask = 1
	query.exclude = [shooter.get_rid()]

	var result: Dictionary = camera.get_world_3d().direct_space_state.intersect_ray(query)

	var aim_point: Vector3 = ray_end
	if not result.is_empty():
		aim_point = result.get("position", ray_end)

	var spawn_position: Vector3 = shooter.global_position + Vector3(0.0, 1.35, 0.0)
	if is_instance_valid(muzzle_point):
		spawn_position = muzzle_point.global_position

	var shot_direction: Vector3 = (aim_point - spawn_position).normalized()
	if shot_direction.length_squared() < 0.001:
		shot_direction = -shooter.global_basis.z

	var projectile = PROJECTILE_SCENE.instantiate()
	if projectile == null:
		return false

	var scene_root: Node = get_tree().current_scene
	if scene_root == null:
		return false

	scene_root.add_child(projectile)
	projectile.global_position = spawn_position
	projectile.set("speed", projectile_speed)
	projectile.set("damage", projectile_damage)
	projectile.call("setup", shot_direction, shooter)

	fire_cooldown = fire_rate

	if is_instance_valid(shot_audio):
		shot_audio.play()

	return true


func _create_shot_audio() -> void:
	shot_audio = AudioStreamPlayer3D.new()
	shot_audio.name = "ShotAudio"
	shot_audio.max_distance = 35.0
	shot_audio.unit_size = 8.0
	shot_audio.stream = _create_tone(180.0, 0.1)
	add_child(shot_audio)


func _create_tone(frequency: float, duration: float) -> AudioStreamWAV:
	var sample_rate: int = 22050
	var sample_count: int = int(sample_rate * duration)
	var data := PackedByteArray()

	for i in range(sample_count):
		var time: float = float(i) / float(sample_rate)
		var envelope: float = 1.0 - (float(i) / float(sample_count))
		var sample: float = sin(TAU * frequency * time) * envelope
		var value: int = clampi(int(128.0 + sample * 100.0), 0, 255)
		data.append(value)

	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_8_BITS
	stream.mix_rate = sample_rate
	stream.stereo = false
	stream.data = data

	return stream