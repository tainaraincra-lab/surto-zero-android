extends CharacterBody3D

# ============================================================
# ZOMBIE AI
# Godot 4.3+
# Persegue, ataca e recebe dano do jogador.
# ============================================================

@export_group("Movimento")

@export var movement_speed: float = 2.2
@export var acceleration: float = 8.0

@export_group("Combate")

@export var max_health: float = 60.0
@export var attack_damage: float = 10.0
@export var attack_range: float = 1.6
@export var attack_cooldown: float = 1.5

@export_group("Percepcao")

@export var detection_range: float = 35.0

var health: float = 60.0
var attack_timer: float = 0.0
var gravity: float = 9.8

var target: Node3D = null
var is_alive: bool = true

var attack_audio: AudioStreamPlayer3D


func _ready() -> void:
    health = max_health

    gravity = float(
        ProjectSettings.get_setting("physics/3d/default_gravity")
    )

    add_to_group("zombies")

    _create_attack_audio()

    print("Zombie criado: ", name)


func _physics_process(delta: float) -> void:
    if not is_alive:
        return

    attack_timer = maxf(attack_timer - delta, 0.0)

    _apply_gravity(delta)

    if GameManager.match_state != GameManager.STATE_PLAYING:
        _stop_horizontal_movement(delta)
        move_and_slide()
        return

    _find_player()

    if not is_instance_valid(target):
        _stop_horizontal_movement(delta)
        move_and_slide()
        return

    var distance: float = global_position.distance_to(
        target.global_position
    )

    if distance > detection_range:
        _stop_horizontal_movement(delta)
        move_and_slide()
        return

    if distance <= attack_range:
        _attack_target()
    else:
        _chase_target(delta)

    move_and_slide()


# ============================================================
# MOVIMENTO
# ============================================================

func _apply_gravity(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif velocity.y < 0.0:
        velocity.y = 0.0


func _stop_horizontal_movement(delta: float) -> void:
    velocity.x = move_toward(
        velocity.x,
        0.0,
        acceleration * delta
    )

    velocity.z = move_toward(
        velocity.z,
        0.0,
        acceleration * delta
    )


func _chase_target(delta: float) -> void:
    var direction: Vector3 = (
        target.global_position - global_position
    )

    direction.y = 0.0

    if direction.length_squared() < 0.001:
        return

    direction = direction.normalized()

    velocity.x = move_toward(
        velocity.x,
        direction.x * movement_speed,
        acceleration * delta
    )

    velocity.z = move_toward(
        velocity.z,
        direction.z * movement_speed,
        acceleration * delta
    )

    var look_position: Vector3 = Vector3(
        target.global_position.x,
        global_position.y,
        target.global_position.z
    )

    look_at(look_position, Vector3.UP)


# ============================================================
# DETECCAO DO JOGADOR
# ============================================================

func _find_player() -> void:
    if is_instance_valid(target):
        if target.is_in_group("player"):
            return

    target = null

    var players: Array[Node] = get_tree().get_nodes_in_group("player")

    if players.is_empty():
        return

    target = players[0] as Node3D


# ============================================================
# ATAQUE
# ============================================================

func _attack_target() -> void:
    if attack_timer > 0.0:
        _stop_horizontal_movement(get_physics_process_delta_time())
        return

    if not is_instance_valid(target):
        return

    var stats: Node = target.get_node_or_null("PlayerStats")

    if stats == null:
        return

    if not stats.get_is_alive():
        return

    _stop_horizontal_movement(get_physics_process_delta_time())

    attack_timer = attack_cooldown

    stats.take_damage(attack_damage)

    _play_attack_sound()

    print("Zombie atacou o jogador. Dano: ", attack_damage)


# ============================================================
# VIDA E DANO
# ============================================================

func take_damage(amount: float) -> void:
    if not is_alive or amount <= 0.0:
        return

    health = clampf(
        health - amount,
        0.0,
        max_health
    )

    print("Zombie recebeu dano. Vida: ", health)

    if health <= 0.0:
        die()


func die() -> void:
    if not is_alive:
        return

    is_alive = false

    velocity = Vector3.ZERO

    print("Zombie eliminado.")

    queue_free()


func get_health() -> float:
    return health


func get_is_alive() -> bool:
    return is_alive


# ============================================================
# AUDIO PROCEDURAL
# ============================================================

func _create_attack_audio() -> void:
    attack_audio = AudioStreamPlayer3D.new()

    attack_audio.name = "AttackAudio"
    attack_audio.max_distance = 25.0

    attack_audio.stream = _create_tone(
        95.0,
        0.12,
        0.35
    )

    add_child(attack_audio)


func _create_tone(
    frequency: float,
    duration: float,
    amplitude: float
) -> AudioStreamWAV:
    var sample_rate: int = 22050
    var sample_count: int = int(sample_rate * duration)

    var samples := PackedByteArray()
    samples.resize(sample_count)

    for i in range(sample_count):
        var time: float = float(i) / float(sample_rate)

        var envelope: float = 1.0 - (
            float(i) / float(sample_count)
        )

        var wave: float = sin(TAU * frequency * time)

        var sample: int = int(
            128.0 + wave * amplitude * envelope * 100.0
        )

        samples[i] = clampi(sample, 0, 255)

    var stream := AudioStreamWAV.new()

    stream.format = AudioStreamWAV.FORMAT_8_BITS
    stream.mix_rate = sample_rate
    stream.stereo = false
    stream.data = samples

    return stream


func _play_attack_sound() -> void:
    if attack_audio == null:
        return

    attack_audio.stop()
    attack_audio.play()