extends Node

signal inventory_changed(ammo: int, medkits: int, water: int)

@export var starting_ammo: int = 60
@export var starting_medkits: int = 1
@export var starting_water: int = 1

var ammo: int = 60
var medkits: int = 1
var water: int = 1


func _ready() -> void:
	reset_inventory()


func reset_inventory() -> void:
	ammo = starting_ammo
	medkits = starting_medkits
	water = starting_water
	_emit_changed()


func add_item(item_type: String, amount: int) -> void:
	if amount <= 0:
		return

	match item_type:
		"ammo":
			ammo += amount
		"medkit":
			medkits += amount
		"water":
			water += amount
		_:
			return

	_emit_changed()


func has_ammo() -> bool:
	return ammo > 0


func consume_ammo(amount: int = 1) -> bool:
	if amount <= 0 or ammo < amount:
		return false

	ammo -= amount
	_emit_changed()
	return true


func consume_medkit() -> bool:
	if medkits <= 0:
		return false

	medkits -= 1
	_emit_changed()
	return true


func consume_water() -> bool:
	if water <= 0:
		return false

	water -= 1
	_emit_changed()
	return true


func get_ammo() -> int:
	return ammo


func get_medkits() -> int:
	return medkits


func get_water() -> int:
	return water


func _emit_changed() -> void:
	inventory_changed.emit(ammo, medkits, water)