extends Node

signal stats_updated(health: float, hunger: float, thirst: float)

@export var max_health: float = 100.0
@export var max_hunger: float = 100.0
@export var max_thirst: float = 100.0

@export var hunger_decay_per_second: float = 0.12
@export var thirst_decay_per_second: float = 0.20

@export var starvation_damage_per_second: float = 1.5
@export var dehydration_damage_per_second: float = 2.5

@export var medkit_heal_amount: float = 45.0
@export var water_restore_amount: float = 40.0

var health: float = 100.0
var hunger: float = 100.0
var thirst: float = 100.0

var is_dead: bool = false


func _ready() -> void:
	reset_stats()


func _process(delta: float) -> void:
	if is_dead:
		return

	if GameManager.current_state != GameManager.STATE_PLAYING:
		return

	hunger = maxf(0.0, hunger - hunger_decay_per_second * delta)
	thirst = maxf(0.0, thirst - thirst_decay_per_second * delta)

	if hunger <= 0.0:
		take_damage(starvation_damage_per_second * delta)

	if thirst <= 0.0:
		take_damage(dehydration_damage_per_second * delta)

	_emit_stats()


func reset_stats() -> void:
	health = max_health
	hunger = max_hunger
	thirst = max_thirst
	is_dead = false
	_emit_stats()


func take_damage(amount: float) -> void:
	if is_dead or amount <= 0.0:
		return

	health = maxf(0.0, health - amount)
	_emit_stats()

	if health <= 0.0:
		_die()


func heal(amount: float) -> void:
	if is_dead or amount <= 0.0:
		return

	health = minf(max_health, health + amount)
	_emit_stats()


func restore_hunger(amount: float) -> void:
	if is_dead or amount <= 0.0:
		return

	hunger = minf(max_hunger, hunger + amount)
	_emit_stats()


func restore_thirst(amount: float) -> void:
	if is_dead or amount <= 0.0:
		return

	thirst = minf(max_thirst, thirst + amount)
	_emit_stats()


func use_medkit() -> bool:
	if is_dead or health >= max_health:
		return false

	heal(medkit_heal_amount)
	return true


func drink_water() -> bool:
	if is_dead or thirst >= max_thirst:
		return false

	restore_thirst(water_restore_amount)
	return true


func get_is_alive() -> bool:
	return not is_dead and health > 0.0


func _die() -> void:
	if is_dead:
		return

	is_dead = true
	health = 0.0
	_emit_stats()
	GameManager.end_match()


func _emit_stats() -> void:
	stats_updated.emit(health, hunger, thirst)