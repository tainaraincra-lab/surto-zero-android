extends CharacterBody3D

signal message_requested(message: String)

@export var walk_speed: float = 4.8
@export var sprint_speed: float = 7.2
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.0025
@export var camera_min_pitch: float = -1.05
@export var camera_max_pitch: float = 0.55
@export var interaction_distance: float = 3.0

const MOBILE_CONTROLS_SCENE := preload("res://scenes/ui/MobileControls.tscn")

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _camera_pitch := -0.08
var _fire_cooldown := 0.0

var _mobile_controls: Control
var _player_stats: Node
var _inventory: Node
var _weapon: Node


func _ready() -> void:
	_player_stats = get_node_or_null("PlayerStats")
	_inventory = get_node_or_null("PlayerInventory")
	_weapon = get_node_or_null("WeaponController")

	_mobile_controls = MOBILE_CONTROLS_SCENE.instantiate()
	add_child(_mobile_controls)

	_camera_pitch = $CameraPivot.rotation.x
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _physics_process(delta: float) -> void:
	_fire_cooldown = maxf(0.0, _fire_cooldown - delta)

	if not _is_match_playing():
		velocity.x = move_toward(velocity.x, 0.0, walk_speed * delta * 5.0)
		velocity.z = move_toward(velocity.z, 0.0, walk_speed * delta * 5.0)

		if not is_on_floor():
			velocity.y -= gravity * delta

		move_and_slide()
		return

	_handle_camera()
	_handle_movement(delta)
	_handle_actions()
	_handle_survival()
	move_and_slide()


func _is_match_playing() -> bool:
	if not is_instance_valid(GameManager):
		return true

	return GameManager.current_state == GameManager.STATE_PLAYING


func _handle_camera() -> void:
	var look: Vector2 = _mobile_controls.call("consume_look_delta")

	if look != Vector2.ZERO:
		rotate_y(-look.x)
		_camera_pitch = clampf(
			_camera_pitch - look.y,
			camera_min_pitch,
			camera_max_pitch
		)
		$CameraPivot.rotation.x = _camera_pitch


func _handle_movement(delta: float) -> void:
	var input_vector := Vector2.ZERO

	input_vector.x = (
		Input.get_action_strength("move_right")
		- Input.get_action_strength("move_left")
	)
	input_vector.y = (
		Input.get_action_strength("move_backward")
		- Input.get_action_strength("move_forward")
	)

	var mobile_vector: Vector2 = _mobile_controls.get("move_vector")

	if mobile_vector.length() > 0.0:
		input_vector = mobile_vector

	input_vector = input_vector.limit_length(1.0)

	var direction := (
		global_transform.basis
		* Vector3(input_vector.x, 0.0, input_vector.y)
	).normalized()

	var sprinting := Input.is_action_pressed("sprint")
	sprinting = sprinting or bool(_mobile_controls.get("sprint_held"))

	var speed := sprint_speed if sprinting else walk_speed

	if direction.length() > 0.01:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed * 6.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, speed * 6.0 * delta)

	if not is_on_floor():
		velocity.y -= gravity * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity

	if _mobile_controls.call("is_action_just_pressed", "jump") and is_on_floor():
		velocity.y = jump_velocity


func _handle_actions() -> void:
	var firing := Input.is_action_pressed("fire")
	firing = firing or bool(_mobile_controls.get("fire_held"))

	if firing and _fire_cooldown <= 0.0:
		_fire_cooldown = 0.22

		if _weapon != null and _weapon.has_method("fire"):
			_weapon.call("fire")

	if Input.is_action_just_pressed("interact"):
		_interact()

	if _mobile_controls.call("is_action_just_pressed", "interact"):
		_interact()


func _handle_survival() -> void:
	if _mobile_controls.call("is_action_just_pressed", "medkit"):
		_use_medkit()

	if _mobile_controls.call("is_action_just_pressed", "water"):
		_drink_water()


func _interact() -> void:
	var camera: Camera3D = $CameraPivot/Camera3D
	var from := camera.global_position
	var to := from + (-camera.global_transform.basis.z * interaction_distance)

	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [get_rid()]
	query.collide_with_areas = true

	var result := get_world_3d().direct_space_state.intersect_ray(query)

	if result.is_empty():
		message_requested.emit("Nada para coletar por perto.")
		return

	var target: Object = result.get("collider")

	if target != null and target.has_method("interact"):
		target.call("interact", self)
	elif target != null and target.has_method("collect"):
		target.call("collect", self)
	else:
		message_requested.emit("Não há item coletável nesse ponto.")


func _use_medkit() -> void:
	if _inventory != null and _inventory.has_method("consume_medkit"):
		var used: bool = _inventory.call("consume_medkit")

		if used and _player_stats != null and _player_stats.has_method("use_medkit"):
			_player_stats.call("use_medkit")
			message_requested.emit("Kit médico utilizado.")
		elif not used:
			message_requested.emit("Você não tem kits médicos.")
	elif _player_stats != null and _player_stats.has_method("use_medkit"):
		_player_stats.call("use_medkit")


func _drink_water() -> void:
	if _inventory != null and _inventory.has_method("consume_water"):
		var used: bool = _inventory.call("consume_water")

		if used and _player_stats != null and _player_stats.has_method("drink_water"):
			_player_stats.call("drink_water")
			message_requested.emit("Água consumida.")
		elif not used:
			message_requested.emit("Você não tem água.")
	elif _player_stats != null and _player_stats.has_method("drink_water"):
		_player_stats.call("drink_water")


func take_damage(amount: float) -> void:
	if _player_stats != null and _player_stats.has_method("take_damage"):
		_player_stats.call("take_damage", amount)


func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	elif event is InputEventMouseMotion:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			rotate_y(-event.relative.x * mouse_sensitivity)
			_camera_pitch = clampf(
				_camera_pitch - event.relative.y * mouse_sensitivity,
				camera_min_pitch,
				camera_max_pitch
			)
			$CameraPivot.rotation.x = _camera_pitch