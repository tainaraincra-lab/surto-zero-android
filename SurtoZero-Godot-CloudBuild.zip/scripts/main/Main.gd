extends Node3D

const PLAYER_SCENE: PackedScene = preload("res://scenes/player/Player.tscn")

@onready var player_spawn: Marker3D = $World/PlayerSpawn
@onready var hud: CanvasLayer = $HUD
@onready var zombie_spawner: Node = $World/ZombieSpawner
@onready var sector_manager: Node = $World/SectorManager

var player: CharacterBody3D


func _ready() -> void:
	_create_player()
	_connect_hud()

	if not GameManager.match_state_changed.is_connected(_on_match_state_changed):
		GameManager.match_state_changed.connect(_on_match_state_changed)

	# Carrega o setor inicial mesmo antes do jogador iniciar a partida.
	if player != null:
		sector_manager.call(
			"update_sectors_for_position",
			player.global_position
		)
		_place_player_on_terrain()

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	hud.call("show_menu")
	_update_hud()


func _process(_delta: float) -> void:
	_update_hud()


func _create_player() -> void:
	player = PLAYER_SCENE.instantiate() as CharacterBody3D

	if player == null:
		push_error("Não foi possível criar o jogador.")
		return

	add_child(player)
	player.global_position = player_spawn.global_position

	if player.has_signal("message_requested"):
		player.message_requested.connect(_on_player_message_requested)


func _connect_hud() -> void:
	if hud.has_signal("start_requested"):
		if not hud.start_requested.is_connected(_on_start_requested):
			hud.start_requested.connect(_on_start_requested)


func _on_start_requested() -> void:
	if GameManager.current_state == GameManager.STATE_PAUSED:
		GameManager.resume_match()
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		return

	_start_new_match()


func _start_new_match() -> void:
	if player == null:
		return

	var stats: Node = player.get_node("PlayerStats")
	var inventory: Node = player.get_node("PlayerInventory")

	stats.call("reset_stats")
	inventory.call("reset_inventory")

	player.global_position = player_spawn.global_position
	player.velocity = Vector3.ZERO

	sector_manager.call(
		"update_sectors_for_position",
		player.global_position
	)
	_place_player_on_terrain()

	zombie_spawner.call("clear_zombies")

	GameManager.start_match()

	zombie_spawner.call("spawn_initial_zombies")

	hud.call("show_playing")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_update_hud()


func _place_player_on_terrain() -> void:
	if player == null:
		return

	var ground_height: float = float(
		sector_manager.call(
			"get_height_at_world",
			player.global_position
		)
	)

	var position_on_ground: Vector3 = player_spawn.global_position
	position_on_ground.y = ground_height + 0.08

	player.global_position = position_on_ground


func _on_match_state_changed(new_state: String) -> void:
	match new_state:
		GameManager.STATE_PLAYING:
			hud.call("show_playing")
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

		GameManager.STATE_PAUSED:
			hud.call("show_paused")
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

		GameManager.STATE_GAME_OVER:
			hud.call("show_game_over")
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

		GameManager.STATE_VICTORY:
			hud.call("show_victory")
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

		_:
			hud.call("show_menu")
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_player_message_requested(message: String) -> void:
	hud.call("show_message", message)


func _update_hud() -> void:
	if player == null or not is_instance_valid(player):
		return

	var stats: Node = player.get_node("PlayerStats")
	var inventory: Node = player.get_node("PlayerInventory")

	hud.call(
		"update_status",
		float(stats.get("health")),
		float(stats.get("hunger")),
		float(stats.get("thirst"))
	)

	hud.call(
		"update_inventory",
		int(inventory.get("ammo")),
		int(inventory.get("medkits")),
		int(inventory.get("water"))
	)

	hud.call(
		"update_world_info",
		sector_manager.call(
			"get_sector_description",
			player.global_position
		),
		sector_manager.call(
			"get_world_coordinates",
			player.global_position
		),
		int(sector_manager.call("get_loaded_sector_count")),
		int(sector_manager.call("get_total_sector_count"))
	)