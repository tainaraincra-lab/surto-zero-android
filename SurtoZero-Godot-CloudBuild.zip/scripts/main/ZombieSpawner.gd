extends Node3D

# ============================================================
# ZOMBIE SPAWNER
# Gerencia a criação e remoção dos zumbis da arena.
# ============================================================

const ZOMBIE_SCENE: PackedScene = preload(
    "res://scenes/enemies/Zombie.tscn"
)

@export_group("Configuração")

@export_range(0, 10, 1) var spawn_count: int = 3
@export var spawn_radius: float = 12.0

var spawned_zombies: Array[Node3D] = []


func _ready() -> void:
    print("ZombieSpawner inicializado.")


# ============================================================
# SPAWN
# ============================================================

func spawn_initial_zombies() -> void:
    clear_zombies()

    var players: Array[Node] = get_tree().get_nodes_in_group("player")

    if players.is_empty():
        push_warning("ZombieSpawner: nenhum jogador encontrado.")
        return

    var player: Node3D = players[0] as Node3D

    if player == null:
        return

    for i in range(spawn_count):
        var angle: float = (
            TAU * float(i) / float(maxi(spawn_count, 1))
        )

        var offset := Vector3(
            cos(angle),
            0.0,
            sin(angle)
        ) * spawn_radius

        var zombie := ZOMBIE_SCENE.instantiate() as Node3D

        if zombie == null:
            push_error("ZombieSpawner: falha ao instanciar zumbi.")
            continue

        add_child(zombie)

        zombie.global_position = player.global_position + offset

        spawned_zombies.append(zombie)

    print("Zumbis criados: ", spawned_zombies.size())


# ============================================================
# REMOÇÃO
# ============================================================

func clear_zombies() -> void:
    for zombie in spawned_zombies:
        if is_instance_valid(zombie):
            zombie.queue_free()

    spawned_zombies.clear()

    # Também limpa eventuais zumbis criados fora da lista.
    for zombie in get_children():
        if zombie.is_in_group("zombies"):
            zombie.queue_free()


# ============================================================
# CONSULTAS
# ============================================================

func get_zombie_count() -> int:
    var count: int = 0

    for zombie in spawned_zombies:
        if is_instance_valid(zombie):
            count += 1

    return count


func get_spawn_count() -> int:
    return spawn_count