extends Area3D

@export_enum("ammo", "medkit", "water") var item_type: String = "ammo"
@export_range(1, 100, 1) var amount: int = 10

@onready var item_mesh: MeshInstance3D = $ItemMesh
@onready var item_label: Label3D = $ItemLabel


func _ready() -> void:
	add_to_group("loot")
	_update_appearance()


func collect(player: Node) -> bool:
	if not is_instance_valid(player):
		return false

	if not player.has_method("add_loot"):
		return false

	var collected: bool = bool(player.call("add_loot", item_type, amount))
	if collected:
		queue_free()

	return collected


func _update_appearance() -> void:
	var item_name: String = ""
	var item_color: Color = Color.WHITE

	match item_type:
		"ammo":
			item_name = "MUNIÇÃO\n+%d" % amount
			item_color = Color(1.0, 0.75, 0.15)
		"medkit":
			item_name = "KIT MÉDICO\n+%d" % amount
			item_color = Color(0.2, 0.9, 0.35)
		"water":
			item_name = "ÁGUA\n+%d" % amount
			item_color = Color(0.2, 0.65, 1.0)
		_:
			item_name = "ITEM"
			item_color = Color.WHITE

	item_label.text = item_name

	var material := StandardMaterial3D.new()
	material.albedo_color = item_color
	material.emission_enabled = true
	material.emission = item_color * 0.35
	item_mesh.material_override = material