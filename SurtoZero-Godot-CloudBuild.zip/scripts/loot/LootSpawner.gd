extends Node3D

const LOOT_SCENE: PackedScene = preload("res://scenes/loot/LootItem.tscn")

@export_range(1, 50, 1) var loot_count: int = 12
@export var spawn_radius: float = 22.0

var spawned_items: Array[Node3D] = []

var loot_positions: Array[Vector2] = [
	Vector2(0, -5),
	Vector2(5, -9),
	Vector2(-8, -7),
	Vector2(11, -3),
	Vector2(-12, 1),
	Vector2(7, 8),
	Vector2(-5, 11),
	Vector2(15, 10),
	Vector2(-16, -10),
	Vector2(2, 17),
	Vector2(-18, 8),
	Vector2(18, -15)
]

var loot_types: Array[String] = [
	"ammo",
	"ammo",
	"ammo",
	"ammo",
	"medkit",
	"medkit",
	"water",
	"water",
	"ammo",
	"water",
	"ammo",
	"medkit"
]


func spawn_initial_loot() -> void:
	clear_loot()

	var player: Node3D = _find_player()
	var center: Vector3 = Vector3.ZERO

	if player != null:
		center = player.global_position

	var amount_to_spawn: int = mini(loot_count, loot_positions.size())

	for i in range(amount_to_spawn):
		var item := LOOT_SCENE.instantiate() as Node3D
		if item == null:
			continue

		var item_type: String = loot_types[i]
		var item_amount: int = _get_item_amount(item_type)

		item.set("item_type", item_type)
		item.set("amount", item_amount)

		add_child(item)

		var offset: Vector2 = loot_positions[i]
		var position := Vector3(
			offset.x,
			0.45,
			offset.y
		)

		if player != null:
			position += Vector3(center.x, 0.0, center.z)

		item.global_position = position
		spawned_items.append(item)


func clear_loot() -> void:
	for item in spawned_items:
		if is_instance_valid(item):
			item.queue_free()

	spawned_items.clear()

	for child in get_children():
		if child.is_in_group("loot"):
			child.queue_free()


func get_loot_count() -> int:
	var count: int = 0

	for item in spawned_items:
		if is_instance_valid(item):
			count += 1

	return count


func _get_item_amount(item_type: String) -> int:
	match item_type:
		"ammo":
			return 15
		"medkit":
			return 1
		"water":
			return 1
		_:
			return 1


func _find_player() -> Node3D:
	var players: Array[Node] = get_tree().get_nodes_in_group("player")

	if players.is_empty():
		return null

	return players[0] as Node3D