extends Node

# ============================================================
# GAME MANAGER
# Gerencia o estado geral da partida.
# ============================================================

signal match_state_changed(new_state: String)
signal stats_changed

const STATE_MENU: String = "menu"
const STATE_PLAYING: String = "playing"
const STATE_PAUSED: String = "paused"
const STATE_GAME_OVER: String = "game_over"
const STATE_VICTORY: String = "victory"

var match_state: String = STATE_MENU

# Estatísticas de exemplo.
var player_health: float = 100.0
var player_hunger: float = 100.0
var player_thirst: float = 100.0

var elapsed_time: float = 0.0


func _ready() -> void:
    print("GameManager inicializado.")
    _emit_updates()


func _process(delta: float) -> void:
    if match_state != STATE_PLAYING:
        return

    elapsed_time += delta


# ------------------------------------------------------------
# PARTIDA
# ------------------------------------------------------------

func start_match() -> void:
    match_state = STATE_PLAYING

    player_health = 100.0
    player_hunger = 100.0
    player_thirst = 100.0

    elapsed_time = 0.0

    print("Partida iniciada.")

    _emit_updates()


func pause_match() -> void:
    if match_state != STATE_PLAYING:
        return

    match_state = STATE_PAUSED
    match_state_changed.emit(match_state)


func resume_match() -> void:
    if match_state != STATE_PAUSED:
        return

    match_state = STATE_PLAYING
    match_state_changed.emit(match_state)


func end_match() -> void:
    match_state = STATE_GAME_OVER
    match_state_changed.emit(match_state)


func win_match() -> void:
    match_state = STATE_VICTORY
    match_state_changed.emit(match_state)


func return_to_menu() -> void:
    match_state = STATE_MENU
    elapsed_time = 0.0
    match_state_changed.emit(match_state)


# ------------------------------------------------------------
# STATUS DO JOGADOR
# ------------------------------------------------------------

func set_player_health(value: float) -> void:
    player_health = clampf(value, 0.0, 100.0)

    if player_health <= 0.0 and match_state == STATE_PLAYING:
        end_match()

    stats_changed.emit()


func set_player_hunger(value: float) -> void:
    player_hunger = clampf(value, 0.0, 100.0)
    stats_changed.emit()


func set_player_thirst(value: float) -> void:
    player_thirst = clampf(value, 0.0, 100.0)
    stats_changed.emit()


func apply_damage(amount: float) -> void:
    if amount <= 0.0:
        return

    set_player_health(player_health - amount)


func heal_player(amount: float) -> void:
    if amount <= 0.0:
        return

    set_player_health(player_health + amount)


# ------------------------------------------------------------
# INFORMAÇÕES
# ------------------------------------------------------------

func get_match_state() -> String:
    return match_state


func get_match_state_text() -> String:
    match match_state:
        STATE_MENU:
            return "AGUARDANDO INÍCIO"

        STATE_PLAYING:
            return "PARTIDA EM ANDAMENTO"

        STATE_PAUSED:
            return "PARTIDA PAUSADA"

        STATE_GAME_OVER:
            return "FIM DE JOGO"

        STATE_VICTORY:
            return "VITÓRIA"

        _:
            return "ESTADO DESCONHECIDO"


func get_player_stats() -> Dictionary:
    return {
        "health": player_health,
        "hunger": player_hunger,
        "thirst": player_thirst
    }


func get_elapsed_time() -> float:
    return elapsed_time


func _emit_updates() -> void:
    match_state_changed.emit(match_state)
    stats_changed.emit()