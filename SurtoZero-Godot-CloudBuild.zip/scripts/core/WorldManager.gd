extends Node

# ============================================================
# WORLD MANAGER
# Gerencia os dados gerais do mundo.
# Preparado para expansão por setores.
# ============================================================

signal world_initialized
signal sector_state_changed(sector_id: Vector2i, loaded: bool)

const WORLD_SIZE: float = 2000.0
const SECTOR_SIZE: float = 250.0
const SECTOR_COUNT: int = 8

var world_seed: int = 0

var initialized: bool = false

# Dicionário de setores ativos.
# Chave: Vector2i
# Valor: bool
var loaded_sectors: Dictionary = {}


func _ready() -> void:
    initialize_world()


# ------------------------------------------------------------
# INICIALIZAÇÃO
# ------------------------------------------------------------

func initialize_world() -> void:
    world_seed = int(Time.get_unix_time_from_system())

    loaded_sectors.clear()

    initialized = true

    print("WorldManager inicializado.")
    print("Dimensão do mundo: ", WORLD_SIZE, " x ", WORLD_SIZE)
    print("Tamanho dos setores: ", SECTOR_SIZE)
    print("Quantidade de setores: ", SECTOR_COUNT * SECTOR_COUNT)

    world_initialized.emit()


func reset_world() -> void:
    loaded_sectors.clear()
    initialize_world()


# ------------------------------------------------------------
# SETORES
# ------------------------------------------------------------

func get_sector_from_position(world_position: Vector3) -> Vector2i:
    var half_world: float = WORLD_SIZE / 2.0

    var normalized_x: float = world_position.x + half_world
    var normalized_z: float = world_position.z + half_world

    var sector_x: int = floori(normalized_x / SECTOR_SIZE)
    var sector_z: int = floori(normalized_z / SECTOR_SIZE)

    sector_x = clampi(sector_x, 0, SECTOR_COUNT - 1)
    sector_z = clampi(sector_z, 0, SECTOR_COUNT - 1)

    return Vector2i(sector_x, sector_z)


func load_sector(sector_id: Vector2i) -> void:
    if not is_sector_valid(sector_id):
        return

    if loaded_sectors.has(sector_id):
        return

    loaded_sectors[sector_id] = true

    print("Setor carregado: ", sector_id)

    sector_state_changed.emit(sector_id, true)


func unload_sector(sector_id: Vector2i) -> void:
    if not loaded_sectors.has(sector_id):
        return

    loaded_sectors.erase(sector_id)

    print("Setor descarregado: ", sector_id)

    sector_state_changed.emit(sector_id, false)


func is_sector_valid(sector_id: Vector2i) -> bool:
    return (
        sector_id.x >= 0
        and sector_id.x < SECTOR_COUNT
        and sector_id.y >= 0
        and sector_id.y < SECTOR_COUNT
    )


func is_sector_loaded(sector_id: Vector2i) -> bool:
    return loaded_sectors.has(sector_id)


func get_loaded_sector_count() -> int:
    return loaded_sectors.size()


func get_world_size() -> float:
    return WORLD_SIZE


func get_sector_size() -> float:
    return SECTOR_SIZE