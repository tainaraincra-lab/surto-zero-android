extends Node

# ============================================================
# SAVE MANAGER
# Gerenciamento básico de salvamento local.
# Utiliza ConfigFile nativo do Godot.
# ============================================================

const SAVE_PATH: String = "user://survival_save.cfg"

signal save_completed
signal save_failed(error_code: int)
signal load_completed


func _ready() -> void:
    print("SaveManager inicializado.")


# ------------------------------------------------------------
# SALVAR
# ------------------------------------------------------------

func save_game() -> bool:
    var config := ConfigFile.new()

    config.set_value(
        "game",
        "match_state",
        GameManager.match_state
    )

    config.set_value(
        "game",
        "elapsed_time",
        GameManager.elapsed_time
    )

    config.set_value(
        "player",
        "health",
        GameManager.player_health
    )

    config.set_value(
        "player",
        "hunger",
        GameManager.player_hunger
    )

    config.set_value(
        "player",
        "thirst",
        GameManager.player_thirst
    )

    config.set_value(
        "world",
        "seed",
        WorldManager.world_seed
    )

    var error: Error = config.save(SAVE_PATH)

    if error != OK:
        push_error("Falha ao salvar o jogo: " + str(error))
        save_failed.emit(error)
        return false

    print("Jogo salvo com sucesso.")

    save_completed.emit()

    return true


# ------------------------------------------------------------
# CARREGAR
# ------------------------------------------------------------

func load_game() -> bool:
    var config := ConfigFile.new()

    var error: Error = config.load(SAVE_PATH)

    if error != OK:
        push_warning("Nenhum salvamento válido encontrado.")
        return false

    GameManager.match_state = str(
        config.get_value(
            "game",
            "match_state",
            GameManager.STATE_MENU
        )
    )

    GameManager.elapsed_time = float(
        config.get_value(
            "game",
            "elapsed_time",
            0.0
        )
    )

    GameManager.player_health = float(
        config.get_value(
            "player",
            "health",
            100.0
        )
    )

    GameManager.player_hunger = float(
        config.get_value(
            "player",
            "hunger",
            100.0
        )
    )

    GameManager.player_thirst = float(
        config.get_value(
            "player",
            "thirst",
            100.0
        )
    )

    WorldManager.world_seed = int(
        config.get_value(
            "world",
            "seed",
            0
        )
    )

    GameManager.stats_changed.emit()
    GameManager.match_state_changed.emit(
        GameManager.match_state
    )

    print("Jogo carregado com sucesso.")

    load_completed.emit()

    return true


# ------------------------------------------------------------
# UTILITÁRIOS
# ------------------------------------------------------------

func has_save() -> bool:
    return FileAccess.file_exists(SAVE_PATH)


func delete_save() -> bool:
    if not has_save():
        return true

    var error: Error = DirAccess.remove_absolute(
        ProjectSettings.globalize_path(SAVE_PATH)
    )

    if error != OK:
        push_error("Falha ao excluir salvamento: " + str(error))
        return false

    return true