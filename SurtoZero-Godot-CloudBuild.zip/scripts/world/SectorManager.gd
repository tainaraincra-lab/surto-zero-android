extends Node3D

const SECTOR_SCRIPT: Script = preload("res://scripts/world/WorldSector.gd")

const WORLD_SIZE: float = 2000.0
const SECTOR_SIZE: float = 250.0
const SECTOR_COUNT: int = 8

@export_range(0, 3, 1) var load_radius: int = 1
@export_range(0.1, 3.0, 0.1) var update_interval: float = 0.5

var loaded_sectors: Dictionary = {}
var update_timer: float = 0.0
var last_center_sector: Vector2i = Vector2i(-999, -999)


func _ready() -> void:
	name = "SectorManager"


func _process(delta: float) -> void:
	update_timer -= delta

	if update_timer > 0.0:
		return

	update_timer = update_interval

	var player: Node3D = _find_player()
	if player == null:
		return

	update_sectors_for_position(player.global_position)


func update_sectors_for_position(player_position: Vector3) -> void:
	var center_sector: Vector2i = world_to_sector(player_position)

	if center_sector == last_center_sector:
		return

	last_center_sector = center_sector

	var required_sectors: Dictionary = {}

	for z in range(
		maxi(0, center_sector.y - load_radius),
		mini(SECTOR_COUNT - 1, center_sector.y + load_radius) + 1
	):
		for x in range(
			maxi(0, center_sector.x - load_radius),
			mini(SECTOR_COUNT - 1, center_sector.x + load_radius) + 1
		):
			var coords := Vector2i(x, z)
			var key: String = _sector_key(coords)

			required_sectors[key] = true

			if not loaded_sectors.has(key):
				_load_sector(coords)

	_unload_unneeded_sectors(required_sectors)


func world_to_sector(world_position: Vector3) -> Vector2i:
	var x: int = int(floor(
		(world_position.x + WORLD_SIZE * 0.5) / SECTOR_SIZE
	))

	var z: int = int(floor(
		(world_position.z + WORLD_SIZE * 0.5) / SECTOR_SIZE
	))

	x = clampi(x, 0, SECTOR_COUNT - 1)
	z = clampi(z, 0, SECTOR_COUNT - 1)

	return Vector2i(x, z)


func get_sector_description(world_position: Vector3) -> String:
	var sector: Vector2i = world_to_sector(world_position)

	return "SETOR %02d-%02d" % [
		sector.x + 1,
		sector.y + 1
	]


func get_loaded_sector_count() -> int:
	return loaded_sectors.size()


func get_total_sector_count() -> int:
	return SECTOR_COUNT * SECTOR_COUNT


func get_world_coordinates(world_position: Vector3) -> String:
	return "X: %d m   Z: %d m" % [
		roundi(world_position.x),
		roundi(world_position.z)
	]


func get_height_at_world(world_position: Vector3) -> float:
	var coords: Vector2i = world_to_sector(world_position)
	var key: String = _sector_key(coords)

	if not loaded_sectors.has(key):
		return 0.0

	var sector: Node3D = loaded_sectors[key] as Node3D
	if not is_instance_valid(sector):
		return 0.0

	var local_x: float = world_position.x - sector.global_position.x
	var local_z: float = world_position.z - sector.global_position.z

	return float(sector.call("get_height_at", local_x, local_z))


func _load_sector(coords: Vector2i) -> void:
	var key: String = _sector_key(coords)

	var sector := Node3D.new()
	sector.name = "Sector_%02d_%02d" % [
		coords.x + 1,
		coords.y + 1
	]
	sector.set_script(SECTOR_SCRIPT)

	add_child(sector)

	var origin_x: float = -WORLD_SIZE * 0.5 + float(coords.x) * SECTOR_SIZE
	var origin_z: float = -WORLD_SIZE * 0.5 + float(coords.y) * SECTOR_SIZE

	sector.global_position = Vector3(
		origin_x + SECTOR_SIZE * 0.5,
		0.0,
		origin_z + SECTOR_SIZE * 0.5
	)

	sector.call("setup", coords.x, coords.y)
	sector.call("generate")

	loaded_sectors[key] = sector


func _unload_unneeded_sectors(required_sectors: Dictionary) -> void:
	var keys_to_remove: Array[String] = []

	for key in loaded_sectors.keys():
		if not required_sectors.has(key):
			keys_to_remove.append(key)

	for key in keys_to_remove:
		var sector: Node = loaded_sectors[key]

		if is_instance_valid(sector):
			sector.queue_free()

		loaded_sectors.erase(key)


func _sector_key(coords: Vector2i) -> String:
	return "%d_%d" % [
		coords.x,
		coords.y
	]


func _find_player() -> Node3D:
	var players: Array[Node] = get_tree().get_nodes_in_group("player")

	if players.is_empty():
		return null

	return players[0] as Node3D