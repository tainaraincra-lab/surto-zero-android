extends Node3D

const LOOT_SCENE: PackedScene = preload("res://scenes/loot/LootItem.tscn")

const SECTOR_SIZE: float = 250.0
const HALF_SIZE: float = 125.0
const TERRAIN_SUBDIVISIONS: int = 24
const TERRAIN_NOISE_SEED: int = 845321

var sector_x: int = 0
var sector_z: int = 0
var world_origin: Vector2 = Vector2.ZERO

var terrain_noise: FastNoiseLite
var random: RandomNumberGenerator

var ground_material: StandardMaterial3D
var road_material: StandardMaterial3D
var ruin_material: StandardMaterial3D
var trunk_material: StandardMaterial3D
var foliage_material: StandardMaterial3D


func setup(p_sector_x: int, p_sector_z: int) -> void:
	sector_x = p_sector_x
	sector_z = p_sector_z

	world_origin = Vector2(
		-1000.0 + float(sector_x) * SECTOR_SIZE,
		-1000.0 + float(sector_z) * SECTOR_SIZE
	)

	random = RandomNumberGenerator.new()
	random.seed = (
		(sector_x + 17) * 73856093
	) ^ (
		(sector_z + 31) * 19349663
	)

	terrain_noise = FastNoiseLite.new()
	terrain_noise.seed = TERRAIN_NOISE_SEED
	terrain_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	terrain_noise.frequency = 0.006
	terrain_noise.fractal_octaves = 3
	terrain_noise.fractal_gain = 0.45

	_create_materials()


func generate() -> void:
	_create_terrain()
	_create_roads()
	_create_ruins()
	_create_trees()
	_create_loot()


func get_height_at(local_x: float, local_z: float) -> float:
	var world_x: float = world_origin.x + local_x
	var world_z: float = world_origin.y + local_z

	var broad: float = terrain_noise.get_noise_2d(world_x, world_z) * 3.0
	var detail: float = terrain_noise.get_noise_2d(
		world_x * 2.4,
		world_z * 2.4
	) * 0.65

	return broad + detail


func _create_materials() -> void:
	ground_material = StandardMaterial3D.new()
	ground_material.albedo_color = Color.WHITE
	ground_material.roughness = 1.0
	ground_material.metallic = 0.0
	ground_material.vertex_color_use_as_albedo = true

	road_material = StandardMaterial3D.new()
	road_material.albedo_color = Color(0.20, 0.19, 0.17, 1.0)
	road_material.roughness = 0.96
	road_material.metallic = 0.02

	ruin_material = StandardMaterial3D.new()
	ruin_material.albedo_color = Color(0.38, 0.37, 0.33, 1.0)
	ruin_material.roughness = 0.95
	ruin_material.metallic = 0.0

	trunk_material = StandardMaterial3D.new()
	trunk_material.albedo_color = Color(0.25, 0.16, 0.09, 1.0)
	trunk_material.roughness = 1.0

	foliage_material = StandardMaterial3D.new()
	foliage_material.albedo_color = Color(0.12, 0.27, 0.12, 1.0)
	foliage_material.roughness = 1.0


func _create_terrain() -> void:
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)

	var step: float = SECTOR_SIZE / float(TERRAIN_SUBDIVISIONS)

	for z_index in range(TERRAIN_SUBDIVISIONS):
		for x_index in range(TERRAIN_SUBDIVISIONS):
			var x0: float = -HALF_SIZE + float(x_index) * step
			var x1: float = x0 + step
			var z0: float = -HALF_SIZE + float(z_index) * step
			var z1: float = z0 + step

			var a := Vector3(x0, get_height_at(x0, z0), z0)
			var b := Vector3(x1, get_height_at(x1, z0), z0)
			var c := Vector3(x0, get_height_at(x0, z1), z1)
			var d := Vector3(x1, get_height_at(x1, z1), z1)

			_add_terrain_vertex(surface, a)
			_add_terrain_vertex(surface, c)
			_add_terrain_vertex(surface, b)

			_add_terrain_vertex(surface, b)
			_add_terrain_vertex(surface, c)
			_add_terrain_vertex(surface, d)

	surface.generate_normals()

	var terrain_mesh: ArrayMesh = surface.commit()

	var terrain_body := StaticBody3D.new()
	terrain_body.name = "TerrainCollision"
	terrain_body.collision_layer = 1
	terrain_body.collision_mask = 1
	add_child(terrain_body)

	var terrain_visual := MeshInstance3D.new()
	terrain_visual.name = "TerrainMesh"
	terrain_visual.mesh = terrain_mesh
	terrain_visual.material_override = ground_material
	add_child(terrain_visual)

	var terrain_collision := CollisionShape3D.new()
	terrain_collision.name = "TerrainShape"
	terrain_collision.shape = terrain_mesh.create_trimesh_shape()
	terrain_body.add_child(terrain_collision)


func _add_terrain_vertex(surface: SurfaceTool, vertex: Vector3) -> void:
	var variation: float = terrain_noise.get_noise_2d(
		vertex.x + world_origin.x + 1200.0,
		vertex.z + world_origin.y - 800.0
	)

	var vertex_color := Color(
		clampf(0.72 + variation * 0.16, 0.0, 1.0),
		clampf(0.80 + variation * 0.13, 0.0, 1.0),
		clampf(0.66 + variation * 0.12, 0.0, 1.0),
		1.0
	)

	surface.set_color(vertex_color)
	surface.add_vertex(vertex)


func _create_roads() -> void:
	# A malha rodoviária usa linhas globais regulares.
	# Cada segmento termina exatamente na borda do setor.
	if sector_x % 2 == 1:
		_add_road_strip(true)

	if sector_z % 2 == 1:
		_add_road_strip(false)


func _add_road_strip(vertical: bool) -> void:
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)

	var segments: int = 32
	var road_width: float = 7.0
	var step: float = SECTOR_SIZE / float(segments)

	for i in range(segments):
		var start: float = -HALF_SIZE + float(i) * step
		var finish: float = start + step

		var a: Vector3
		var b: Vector3
		var c: Vector3
		var d: Vector3

		if vertical:
			a = Vector3(-road_width * 0.5, get_height_at(-road_width * 0.5, start) + 0.12, start)
			b = Vector3(road_width * 0.5, get_height_at(road_width * 0.5, start) + 0.12, start)
			c = Vector3(-road_width * 0.5, get_height_at(-road_width * 0.5, finish) + 0.12, finish)
			d = Vector3(road_width * 0.5, get_height_at(road_width * 0.5, finish) + 0.12, finish)
		else:
			a = Vector3(start, get_height_at(start, -road_width * 0.5) + 0.12, -road_width * 0.5)
			b = Vector3(start, get_height_at(start, road_width * 0.5) + 0.12, road_width * 0.5)
			c = Vector3(finish, get_height_at(finish, -road_width * 0.5) + 0.12, -road_width * 0.5)
			d = Vector3(finish, get_height_at(finish, road_width * 0.5) + 0.12, road_width * 0.5)

		surface.add_vertex(a)
		surface.add_vertex(c)
		surface.add_vertex(b)

		surface.add_vertex(b)
		surface.add_vertex(c)
		surface.add_vertex(d)

	surface.generate_normals()

	var road_visual := MeshInstance3D.new()
	road_visual.name = "Road"
	road_visual.mesh = surface.commit()
	road_visual.material_override = road_material
	add_child(road_visual)


func _create_ruins() -> void:
	var ruin_count: int = random.randi_range(2, 5)

	for i in range(ruin_count):
		var local_x: float = random.randf_range(-105.0, 105.0)
		var local_z: float = random.randf_range(-105.0, 105.0)

		if absf(local_x) < 13.0 or absf(local_z) < 13.0:
			continue

		var width: float = random.randf_range(5.0, 12.0)
		var depth: float = random.randf_range(5.0, 12.0)
		var height: float = random.randf_range(2.0, 5.0)

		_add_obstacle_box(
			"Ruin",
			Vector3(
				local_x,
				get_height_at(local_x, local_z) + height * 0.5,
				local_z
			),
			Vector3(width, height, depth),
			ruin_material
		)

		for wall_index in range(2):
			var offset_x: float = random.randf_range(-width, width)
			var offset_z: float = random.randf_range(-depth, depth)
			var wall_height: float = random.randf_range(0.7, 2.0)

			var fragment_x: float = local_x + offset_x
			var fragment_z: float = local_z + offset_z

			_add_obstacle_box(
				"RuinFragment",
				Vector3(
					fragment_x,
					get_height_at(fragment_x, fragment_z) + wall_height * 0.5,
					fragment_z
				),
				Vector3(
					random.randf_range(1.0, 3.0),
					wall_height,
					random.randf_range(1.0, 3.0)
				),
				ruin_material
			)


func _create_trees() -> void:
	var tree_count: int = random.randi_range(9, 17)

	for i in range(tree_count):
		var local_x: float = random.randf_range(-115.0, 115.0)
		var local_z: float = random.randf_range(-115.0, 115.0)

		if absf(local_x) < 10.0 or absf(local_z) < 10.0:
			continue

		_add_tree(local_x, local_z)


func _add_tree(local_x: float, local_z: float) -> void:
	var ground_height: float = get_height_at(local_x, local_z)
	var trunk_height: float = random.randf_range(2.2, 3.6)
	var canopy_size: float = random.randf_range(1.4, 2.2)

	var tree_root := Node3D.new()
	tree_root.name = "Tree"
	tree_root.position = Vector3(local_x, ground_height, local_z)
	add_child(tree_root)

	var trunk := StaticBody3D.new()
	trunk.name = "Trunk"
	trunk.collision_layer = 1
	trunk.collision_mask = 1
	tree_root.add_child(trunk)

	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.18
	trunk_mesh.bottom_radius = 0.28
	trunk_mesh.height = trunk_height

	var trunk_visual := MeshInstance3D.new()
	trunk_visual.mesh = trunk_mesh
	trunk_visual.material_override = trunk_material
	trunk_visual.position.y = trunk_height * 0.5
	trunk.add_child(trunk_visual)

	var trunk_shape := CollisionShape3D.new()
	var trunk_collision := CylinderShape3D.new()
	trunk_collision.radius = 0.28
	trunk_collision.height = trunk_height
	trunk_shape.shape = trunk_collision
	trunk_shape.position.y = trunk_height * 0.5
	trunk.add_child(trunk_shape)

	var canopy := MeshInstance3D.new()
	var canopy_mesh := SphereMesh.new()
	canopy_mesh.radius = canopy_size
	canopy_mesh.height = canopy_size * 2.0
	canopy.mesh = canopy_mesh
	canopy.material_override = foliage_material
	canopy.position.y = trunk_height + canopy_size * 0.55
	tree_root.add_child(canopy)


func _create_loot() -> void:
	var loot_count: int = random.randi_range(1, 3)

	for i in range(loot_count):
		var local_x: float = random.randf_range(-105.0, 105.0)
		var local_z: float = random.randf_range(-105.0, 105.0)

		var item := LOOT_SCENE.instantiate() as Node3D
		if item == null:
			continue

		var item_roll: int = random.randi_range(0, 9)
		var item_type: String

		if item_roll <= 5:
			item_type = "ammo"
		elif item_roll <= 7:
			item_type = "water"
		else:
			item_type = "medkit"

		item.set("item_type", item_type)

		match item_type:
			"ammo":
				item.set("amount", random.randi_range(10, 20))
			"water":
				item.set("amount", 1)
			"medkit":
				item.set("amount", 1)

		add_child(item)

		item.position = Vector3(
			local_x,
			get_height_at(local_x, local_z) + 0.5,
			local_z
		)


func _add_obstacle_box(
	object_name: String,
	local_position: Vector3,
	dimensions: Vector3,
	material: Material
) -> void:
	var body := StaticBody3D.new()
	body.name = object_name
	body.position = local_position
	body.collision_layer = 1
	body.collision_mask = 1
	add_child(body)

	var box_mesh := BoxMesh.new()
	box_mesh.size = dimensions

	var visual := MeshInstance3D.new()
	visual.mesh = box_mesh
	visual.material_override = material
	body.add_child(visual)

	var box_shape := BoxShape3D.new()
	box_shape.size = dimensions

	var collision := CollisionShape3D.new()
	collision.shape = box_shape
	body.add_child(collision)