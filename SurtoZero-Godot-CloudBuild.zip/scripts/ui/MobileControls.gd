
extends CanvasLayer
class_name MobileControls

signal joystick_changed(direction: Vector2)
signal camera_changed(delta: Vector2)
signal shoot_pressed
signal shoot_released
signal interact_pressed
signal jump_pressed
signal jump_released
signal sprint_pressed
signal sprint_released
signal kit_pressed
signal water_pressed

@export_group("Joystick")
@export var joystick_radius: float = 85.0
@export var joystick_deadzone: float = 0.12
@export var joystick_size: float = 170.0

@export_group("Camera")
@export var camera_sensitivity: float = 0.006
@export var camera_enabled: bool = true

@export_group("Buttons")
@export var button_size: float = 64.0
@export var button_margin: float = 24.0

var joystick_direction: Vector2 = Vector2.ZERO
var camera_delta: Vector2 = Vector2.ZERO

var _screen_size: Vector2 = Vector2.ZERO
var _joystick_center: Vector2 = Vector2.ZERO

var _joystick_touch_id: int = -1
var _camera_touch_id: int = -1

var _shooting: bool = false
var _jumping: bool = false
var _sprinting: bool = false

var _joystick_draw: Control = null

var _shoot_button: Button = null
var _interact_button: Button = null
var _jump_button: Button = null
var _sprint_button: Button = null
var _kit_button: Button = null
var _water_button: Button = null


class JoystickDraw:
	extends Control

	var radius: float = 85.0
	var direction: Vector2 = Vector2.ZERO
	var active: bool = false

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		queue_redraw()

	func set_joystick(value: Vector2, enabled: bool) -> void:
		direction = value
		active = enabled
		queue_redraw()

	func _draw() -> void:
		var center: Vector2 = size * 0.5

		if active:
			draw_circle(
				center,
				radius,
				Color(0.15, 0.15, 0.15, 0.35)
			)

			draw_arc(
				center,
				radius,
				0.0,
				TAU,
				48,
				Color(1.0, 1.0, 1.0, 0.35),
				2.0
			)

			draw_circle(
				center + direction * radius,
				24.0,
				Color(0.85, 0.85, 0.85, 0.75)
			)


func _ready() -> void:
	_screen_size = get_viewport().get_visible_rect().size
	_create_joystick_draw()
	_create_buttons()
	get_viewport().size_changed.connect(_on_viewport_resized)


func _process(_delta: float) -> void:
	camera_delta = Vector2.ZERO


func _create_joystick_draw() -> void:
	_joystick_draw = JoystickDraw.new()
	_joystick_draw.name = "JoystickDraw"
	_joystick_draw.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_joystick_draw.radius = joystick_radius
	_joystick_draw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_joystick_draw)


func _create_buttons() -> void:
	_shoot_button = _create_button("Shoot", "TIRO")
	_interact_button = _create_button("Interact", "USAR")
	_jump_button = _create_button("Jump", "PULAR")
	_sprint_button = _create_button("Sprint", "CORRER")
	_kit_button = _create_button("Kit", "KIT")
	_water_button = _create_button("Water", "ÁGUA")

	_shoot_button.button_down.connect(_on_shoot_down)
	_shoot_button.button_up.connect(_on_shoot_up)

	_interact_button.pressed.connect(_on_interact)

	_jump_button.button_down.connect(_on_jump_down)
	_jump_button.button_up.connect(_on_jump_up)

	_sprint_button.button_down.connect(_on_sprint_down)
	_sprint_button.button_up.connect(_on_sprint_up)

	_kit_button.pressed.connect(_on_kit)
	_water_button.pressed.connect(_on_water)

	_reposition_buttons()


func _create_button(button_name: String, button_text: String) -> Button:
	var button: Button = Button.new()

	button.name = button_name
	button.text = button_text
	button.custom_minimum_size = Vector2(button_size, button_size)
	button.size = Vector2(button_size, button_size)
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_filter = Control.MOUSE_FILTER_STOP

	button.add_theme_font_size_override("font_size", 12)

	add_child(button)

	return button


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch: InputEventScreenTouch = event as InputEventScreenTouch
		_handle_screen_touch(touch)

	elif event is InputEventScreenDrag:
		var drag: InputEventScreenDrag = event as InputEventScreenDrag
		_handle_screen_drag(drag)


func _handle_screen_touch(event: InputEventScreenTouch) -> void:
	var position: Vector2 = event.position
	var touch_index: int = event.index

	if event.pressed:
		if _is_over_button(position):
			return

		if _joystick_touch_id == -1 and position.x < _screen_size.x * 0.45:
			_joystick_touch_id = touch_index
			_joystick_center = position
			_update_joystick(position)
			return

		if camera_enabled and _camera_touch_id == -1:
			_camera_touch_id = touch_index

	else:
		if touch_index == _joystick_touch_id:
			_joystick_touch_id = -1
			joystick_direction = Vector2.ZERO
			joystick_changed.emit(Vector2.ZERO)
			_update_joystick_visual()

		if touch_index == _camera_touch_id:
			_camera_touch_id = -1


func _handle_screen_drag(event: InputEventScreenDrag) -> void:
	var touch_position: Vector2 = event.position
	var touch_index: int = event.index

	if touch_index == _joystick_touch_id:
		_update_joystick(touch_position)

	elif touch_index == _camera_touch_id and camera_enabled:
		var delta: Vector2 = event.relative * camera_sensitivity
		camera_delta = delta
		camera_changed.emit(delta)


func _update_joystick(position: Vector2) -> void:
	var offset: Vector2 = position - _joystick_center
	var distance: float = offset.length()

	if distance > joystick_radius:
		offset = offset.normalized() * joystick_radius

	var direction: Vector2 = Vector2.ZERO

	if joystick_radius > 0.0:
		direction = offset / joystick_radius

	if direction.length() < joystick_deadzone:
		direction = Vector2.ZERO

	joystick_direction = direction

	joystick_changed.emit(joystick_direction)
	_update_joystick_visual()


func _update_joystick_visual() -> void:
	if _joystick_draw != null:
		var active: bool = _joystick_touch_id != -1
		_joystick_draw.set_joystick(joystick_direction, active)


func _is_over_button(position: Vector2) -> bool:
	var buttons: Array[Button] = [
		_shoot_button,
		_interact_button,
		_jump_button,
		_sprint_button,
		_kit_button,
		_water_button
	]

	for button: Button in buttons:
		if button != null and button.get_global_rect().has_point(position):
			return true

	return false


func _on_shoot_down() -> void:
	_shooting = true
	shoot_pressed.emit()


func _on_shoot_up() -> void:
	_shooting = false
	shoot_released.emit()


func _on_interact() -> void:
	interact_pressed.emit()


func _on_jump_down() -> void:
	_jumping = true
	jump_pressed.emit()


func _on_jump_up() -> void:
	_jumping = false
	jump_released.emit()


func _on_sprint_down() -> void:
	_sprinting = true
	sprint_pressed.emit()


func _on_sprint_up() -> void:
	_sprinting = false
	sprint_released.emit()


func _on_kit() -> void:
	kit_pressed.emit()


func _on_water() -> void:
	water_pressed.emit()


func _on_viewport_resized() -> void:
	_screen_size = get_viewport().get_visible_rect().size
	_reposition_buttons()


func _reposition_buttons() -> void:
	if _shoot_button == null:
		return

	_shoot_button.position = Vector2(
		_screen_size.x - button_margin - button_size,
		_screen_size.y - button_margin - button_size * 2.0
	)

	_interact_button.position = Vector2(
		_screen_size.x - button_margin - button_size * 2.1,
		_screen_size.y - button_margin - button_size * 1.2
	)

	_jump_button.position = Vector2(
		_screen_size.x - button_margin - button_size * 2.1,
		_screen_size.y - button_margin - button_size * 2.2
	)

	_sprint_button.position = Vector2(
		button_margin,
		_screen_size.y - button_margin - button_size * 2.0
	)

	_kit_button.position = Vector2(
		button_margin + button_size * 1.2,
		_screen_size.y - button_margin - button_size * 2.0
	)

	_water_button.position = Vector2(
		button_margin + button_size * 2.4,
		_screen_size.y - button_margin - button_size * 2.0
	)


func get_joystick_direction() -> Vector2:
	return joystick_direction


func get_camera_delta() -> Vector2:
	return camera_delta


func is_shooting() -> bool:
	return _shooting


func is_jumping() -> bool:
	return _jumping


func is_sprinting() -> bool:
	return _sprinting
