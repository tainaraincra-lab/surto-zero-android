extends CanvasLayer

signal start_requested

@onready var start_button: Button = $Root/Panel/Content/StartButton
@onready var status_label: Label = $Root/Panel/Content/StatusLabel
@onready var inventory_label: Label = $Root/Panel/Content/InventoryLabel
@onready var world_label: Label = $Root/Panel/Content/WorldLabel
@onready var message_label: Label = $Root/Panel/Content/MessageLabel

var message_time_left: float = 0.0


func _ready() -> void:
	start_button.pressed.connect(_on_start_button_pressed)
	show_menu()


func _process(delta: float) -> void:
	if message_time_left > 0.0:
		message_time_left -= delta

		if message_time_left <= 0.0:
			message_label.text = ""


func _on_start_button_pressed() -> void:
	start_requested.emit()


func show_menu() -> void:
	start_button.visible = true
	start_button.text = "INICIAR PARTIDA"
	status_label.text = "SOBREVIVÊNCIA"
	inventory_label.text = "Prepare-se para sobreviver."
	world_label.text = "MUNDO: 2.000 x 2.000 m"
	message_label.text = ""


func show_playing() -> void:
	start_button.visible = false


func show_paused() -> void:
	start_button.visible = true
	start_button.text = "CONTINUAR"
	status_label.text = "PARTIDA PAUSADA"


func show_game_over() -> void:
	start_button.visible = true
	start_button.text = "JOGAR NOVAMENTE"
	status_label.text = "VOCÊ MORREU"


func show_victory() -> void:
	start_button.visible = true
	start_button.text = "JOGAR NOVAMENTE"
	status_label.text = "VITÓRIA"


func update_status(health: float, hunger: float, thirst: float) -> void:
	status_label.text = "VIDA: %d   FOME: %d   SEDE: %d" % [
		roundi(health),
		roundi(hunger),
		roundi(thirst)
	]


func update_inventory(ammo: int, medkits: int, water: int) -> void:
	inventory_label.text = (
		"MUNIÇÃO: %d   KITS: %d   ÁGUA: %d\n"
		+ "H: usar kit médico     Q: beber água     E: coletar"
	) % [
		ammo,
		medkits,
		water
	]


func update_world_info(
	sector_description: String,
	coordinates: String,
	loaded_count: int,
	total_count: int
) -> void:
	world_label.text = "%s\n%s\nSETORES CARREGADOS: %d / %d" % [
		sector_description,
		coordinates,
		loaded_count,
		total_count
	]


func show_message(message: String, duration: float = 2.5) -> void:
	message_label.text = message
	message_time_left = duration